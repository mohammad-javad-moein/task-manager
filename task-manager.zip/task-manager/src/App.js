import React from "react";
import { Provider } from "react-redux";
import { store } from "./app/store";
import TaskList from "./features/tasks/TaskList";
import AddTaskForm from "./features/tasks/AddTaskForm";
import "./App.scss";

function App() {
  return (
    <Provider store={store}>
      <div className="App">
        <h1>Task Manager</h1>
        <AddTaskForm />
        <TaskList />
      </div>
    </Provider>
  );
}

export default App;
