import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchTasks, deleteTask } from "./taskSlice";
import InfiniteScroll from "react-infinite-scroll-component";
import TaskItem from "./TaskItem";
import "./TaskList.scss";

const TaskList = () => {
  const dispatch = useDispatch();
  const tasks = useSelector((state) => state.tasks.tasks);
  const status = useSelector((state) => state.tasks.status);
  const error = useSelector((state) => state.tasks.error);
  const hasMore = useSelector((state) => state.tasks.hasMore);
  const [page, setPage] = useState(1);

  useEffect(() => {
    if (status === "idle") {
      dispatch(fetchTasks(page));
    }
  }, [status, dispatch, page]);

  const fetchMoreTasks = () => {
    if (hasMore) {
      setPage((prevPage) => prevPage + 1);
      dispatch(fetchTasks(page + 1));
    }
  };

  const handleDelete = (taskId) => {
    dispatch(deleteTask(taskId));
  };

  if (status === "loading" && page === 1) {
    return <div>Loading...</div>;
  }

  if (status === "failed") {
    return <div>Error: {error}</div>;
  }

  return (
    <InfiniteScroll
      dataLength={tasks.length}
      next={fetchMoreTasks}
      hasMore={hasMore}
      loader={<h4>Loading...</h4>}
      endMessage={<p>No more tasks to load</p>}
    >
      <div className="task-list">
        {tasks.map((task) => (
          <TaskItem
            key={task.id + Math.random()}
            task={task}
            onDelete={() => handleDelete(task.id)}
          />
        ))}
      </div>
    </InfiniteScroll>
  );
};

export default TaskList;
