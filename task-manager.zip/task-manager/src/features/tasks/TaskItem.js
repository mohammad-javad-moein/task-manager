import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { updateTask } from "./taskSlice";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "./TaskItem.scss";

const TaskItem = React.memo(({ task, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const dispatch = useDispatch();

  const validationSchema = Yup.object({
    title: Yup.string().required("Title is required"),
    description: Yup.string().required("Description is required"),
  });

  const handleUpdate = (values) => {
    dispatch(updateTask({ id: task.id, ...values }));
    setIsEditing(false);
  };

  return (
    <div className="task-item">
      {isEditing ? (
        <Formik
          initialValues={{ title: task.title, description: task.description }}
          validationSchema={validationSchema}
          onSubmit={handleUpdate}
        >
          <Form>
            <Field type="text" name="title" />
            <ErrorMessage name="title" component="div" className="error" />
            <Field type="text" name="description" />
            <ErrorMessage
              name="description"
              component="div"
              className="error"
            />
            <button type="submit">Save</button>
          </Form>
        </Formik>
      ) : (
        <>
          <h3>{task.title}</h3>
          <p>{task.description}</p>
          <img src={task.image} alt={task.title} />
        </>
      )}
      <div className="task-item__actions">
        {!isEditing && <button onClick={() => setIsEditing(true)}>Edit</button>}
        <button onClick={onDelete}>Delete</button>
      </div>
    </div>
  );
});

export default TaskItem;
