import React from "react";
import { useDispatch } from "react-redux";
import { addTask } from "./taskSlice";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "./AddTaskForm.scss";

const AddTaskForm = () => {
  const dispatch = useDispatch();

  const validationSchema = Yup.object({
    title: Yup.string().required("Title is required"),
    description: Yup.string().required("Description is required"),
  });

  return (
    <Formik
      initialValues={{ title: "", description: "" }}
      validationSchema={validationSchema}
      onSubmit={(values, { resetForm }) => {
        dispatch(addTask({ ...values, image: "" }));
        resetForm();
      }}
    >
      <Form className="add-task-form">
        <div className="add-task-form__field">
          <Field type="text" name="title" placeholder="Title" />
          <ErrorMessage name="title" component="div" className="error" />
        </div>
        <div>
          <Field type="text" name="description" placeholder="Description" />
          <ErrorMessage name="description" component="div" className="error" />
        </div>
        <button type="submit">Add Task</button>
      </Form>
    </Formik>
  );
};

export default AddTaskForm;
